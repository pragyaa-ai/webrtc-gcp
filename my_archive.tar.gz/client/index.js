import routes from "/:routes.js";
import create from "/:create.jsx";

export default {
  context: import("/:context.js"),
  routes,
  create,
};
